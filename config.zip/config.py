import math

class Config:
    def __init__(self, nPhotos):
        self.nPhotos = nPhotos
    def setData(self, data):
        self.data = data